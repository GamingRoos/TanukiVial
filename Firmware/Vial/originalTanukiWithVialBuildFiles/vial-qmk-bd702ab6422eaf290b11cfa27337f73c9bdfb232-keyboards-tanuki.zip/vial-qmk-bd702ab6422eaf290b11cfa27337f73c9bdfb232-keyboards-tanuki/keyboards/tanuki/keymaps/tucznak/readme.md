# TuCZnak's modified layout

This layout is optimized for Czech national QWERTZ keymap.
It includes separated layers for:
 - F-keys and numbers
 - national and special characters
 - navigation cluster
 - keyboard config and media control
